﻿
namespace Project_Countries_Frank
{
    partial class Quiz_Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Quiz_Form2));
            this.groupBox_antwort = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox_score = new System.Windows.Forms.GroupBox();
            this.label_score = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox_frage = new System.Windows.Forms.GroupBox();
            this.label_Countrie_Capital = new System.Windows.Forms.Label();
            this.groupBox_antwort.SuspendLayout();
            this.groupBox_score.SuspendLayout();
            this.groupBox_frage.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_antwort
            // 
            this.groupBox_antwort.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_antwort.Controls.Add(this.button4);
            this.groupBox_antwort.Controls.Add(this.button3);
            this.groupBox_antwort.Controls.Add(this.button2);
            this.groupBox_antwort.Controls.Add(this.button1);
            this.groupBox_antwort.Location = new System.Drawing.Point(178, 260);
            this.groupBox_antwort.Name = "groupBox_antwort";
            this.groupBox_antwort.Size = new System.Drawing.Size(501, 339);
            this.groupBox_antwort.TabIndex = 0;
            this.groupBox_antwort.TabStop = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Sienna;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Font = new System.Drawing.Font("Tw Cen MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(266, 187);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(210, 120);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Answer_option_selected);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Sienna;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Font = new System.Drawing.Font("Tw Cen MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(33, 187);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(210, 120);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Answer_option_selected);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Sienna;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Font = new System.Drawing.Font("Tw Cen MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(266, 45);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(210, 123);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Answer_option_selected);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Sienna;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("Tw Cen MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(33, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(210, 123);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Answer_option_selected);
            // 
            // groupBox_score
            // 
            this.groupBox_score.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_score.Controls.Add(this.label_score);
            this.groupBox_score.Controls.Add(this.label1);
            this.groupBox_score.Location = new System.Drawing.Point(12, 260);
            this.groupBox_score.Name = "groupBox_score";
            this.groupBox_score.Size = new System.Drawing.Size(142, 338);
            this.groupBox_score.TabIndex = 1;
            this.groupBox_score.TabStop = false;
            // 
            // label_score
            // 
            this.label_score.AutoSize = true;
            this.label_score.BackColor = System.Drawing.Color.Transparent;
            this.label_score.Font = new System.Drawing.Font("Tw Cen MT Condensed", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_score.ForeColor = System.Drawing.Color.Transparent;
            this.label_score.Location = new System.Drawing.Point(47, 79);
            this.label_score.Name = "label_score";
            this.label_score.Size = new System.Drawing.Size(41, 49);
            this.label_score.TabIndex = 2;
            this.label_score.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tw Cen MT Condensed", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(20, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 49);
            this.label1.TabIndex = 1;
            this.label1.Text = "Score";
            // 
            // groupBox_frage
            // 
            this.groupBox_frage.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_frage.Controls.Add(this.label_Countrie_Capital);
            this.groupBox_frage.Location = new System.Drawing.Point(176, 25);
            this.groupBox_frage.Name = "groupBox_frage";
            this.groupBox_frage.Size = new System.Drawing.Size(502, 208);
            this.groupBox_frage.TabIndex = 2;
            this.groupBox_frage.TabStop = false;
            // 
            // label_Countrie_Capital
            // 
            this.label_Countrie_Capital.AutoSize = true;
            this.label_Countrie_Capital.BackColor = System.Drawing.Color.Transparent;
            this.label_Countrie_Capital.Font = new System.Drawing.Font("Tw Cen MT Condensed", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Countrie_Capital.ForeColor = System.Drawing.Color.Transparent;
            this.label_Countrie_Capital.Location = new System.Drawing.Point(197, 77);
            this.label_Countrie_Capital.Name = "label_Countrie_Capital";
            this.label_Countrie_Capital.Size = new System.Drawing.Size(115, 49);
            this.label_Countrie_Capital.TabIndex = 0;
            this.label_Countrie_Capital.Text = "label1";
            // 
            // Quizz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(700, 611);
            this.Controls.Add(this.groupBox_frage);
            this.Controls.Add(this.groupBox_score);
            this.Controls.Add(this.groupBox_antwort);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Quizz";
            this.Text = "Quizz";
            this.groupBox_antwort.ResumeLayout(false);
            this.groupBox_score.ResumeLayout(false);
            this.groupBox_score.PerformLayout();
            this.groupBox_frage.ResumeLayout(false);
            this.groupBox_frage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_antwort;
        private System.Windows.Forms.GroupBox groupBox_score;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox_frage;
        private System.Windows.Forms.Label label_Countrie_Capital;
        private System.Windows.Forms.Label label_score;
        private System.Windows.Forms.Label label1;
    }
}